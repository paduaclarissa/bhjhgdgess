/* FindIt: Campus Lost and Found | Week 2 prototype (complete)
   Features: 1 Report form, 2 Item feed, 3 Search/filter, 4 Edit/delete,
             5 Claim verification, 6 Match score */

const STORAGE_KEY = "findit_items";
const CATEGORIES = ["Bags", "Electronics", "ID and Cards", "Keys", "Wallet and Money", "Clothing", "Books and Stationery", "Others"];
const LOCATIONS = ["Main Gate", "Library", "Canteen", "Gymnasium", "SITE Building", "Chapel", "Parking Area", "Others"];

let items = [];        // all reports (array of objects)
let editingId = null;  // id of the item being edited, or null
let messageTimer = null;
const MAX_ATTEMPTS = 3;
const MATCH_MIN = 40;
let claimingId = null; // id of the item in the claim window

const $ = (id) => document.getElementById(id);
const form = $("reportForm");

/* ---------- Helpers ---------- */
function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function todayString() {
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  return now.toISOString().slice(0, 10);
}

function formatDate(value) {
  const d = new Date(value + "T00:00:00");
  return isNaN(d) ? value : d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
}

function showMessage(text, kind) {
  const box = $("message");
  box.textContent = text;
  box.className = "message " + (kind === "bad" ? "bad" : "ok");
  box.hidden = false;
  clearTimeout(messageTimer);
  messageTimer = setTimeout(() => { box.hidden = true; }, 3500);
}

function fillSelect(select, options, firstLabel) {
  select.innerHTML = "";
  const first = el("option", "", firstLabel);
  first.value = "";
  select.appendChild(first);
  options.forEach((o) => {
    const opt = el("option", "", o);
    opt.value = o;
    select.appendChild(opt);
  });
}

/* ---------- Storage (localStorage) ---------- */
function seedItems() {
  return [
    { id: 1, type: "lost", name: "Black umbrella", category: "Others", location: "Library", date: "2026-10-28",
      description: "Black umbrella with a wooden handle, left near the reading tables.", contact: "09171234567",
      question: "", answer: "", status: "open", attempts: 0, createdAt: "2026-10-28T09:00:00.000Z" },
    { id: 2, type: "found", name: "Black folding umbrella", category: "Others", location: "Library", date: "2026-10-29",
      description: "Small black folding umbrella found on a chair.", contact: "09181234567",
      question: "What is written on the handle?", answer: "dagupan", status: "open", attempts: 0, createdAt: "2026-10-29T10:00:00.000Z" },
    { id: 3, type: "found", name: "Student ID card", category: "ID and Cards", location: "Main Gate", date: "2026-10-30",
      description: "Student ID card found near the guard house.", contact: "09191234567",
      question: "What is printed on the back of the ID?", answer: "bsit", status: "open", attempts: 0, createdAt: "2026-10-30T08:00:00.000Z" },
    { id: 4, type: "found", name: "Scientific calculator", category: "Electronics", location: "SITE Building", date: "2026-10-25",
      description: "Gray scientific calculator found in the computer lab.", contact: "09201234567",
      question: "What sticker is on the cover?", answer: "star", status: "claimed", attempts: 1, createdAt: "2026-10-25T13:00:00.000Z" }
  ];
}

function loadItems() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) {            // first visit: start with sample records
      items = seedItems();
      persist();
    } else {
      items = JSON.parse(raw);
      if (!Array.isArray(items)) throw new Error("Bad data");
    }
  } catch (err) {
    items = [];
    showMessage("Saved data could not be read. Starting with an empty list.", "bad");
  }
}

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (err) {
    showMessage("Could not save to the browser. Storage may be full or blocked.", "bad");
  }
}

/* ---------- FEATURE 1: Report form (Member 1) ---------- */
function setReportType() {
  const type = form.elements.type.value;
  $("foundOnly").hidden = type !== "found";
  $("locationLabel").textContent = type === "found" ? "Found at" : "Last seen at";
  $("dateLabel").textContent = type === "found" ? "Date found" : "Date lost";
  if (type !== "found") { showError("question", ""); showError("answer", ""); }
}

function checkField(name) {
  const value = form.elements[name].value.trim();
  switch (name) {
    case "name": return value.length < 2 ? "Enter the item name (at least 2 characters)." : "";
    case "category": return value === "" ? "Choose a category." : "";
    case "location": return value === "" ? "Choose a location." : "";
    case "date":
      if (value === "") return "Choose a date.";
      return value > todayString() ? "The date cannot be in the future." : "";
    case "description": return value.length < 10 ? "Describe the item in at least 10 characters." : "";
    case "contact":
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) || /^09\d{9}$/.test(value)
        ? "" : "Enter a valid email or an 11-digit number starting with 09.";
    case "question": return value.length < 5 ? "Write a security question (at least 5 characters)." : "";
    case "answer": return value === "" ? "Enter the secret answer." : "";
  }
  return "";
}

function showError(name, message) {
  const slot = document.querySelector('.error[data-for="' + name + '"]');
  if (slot) slot.textContent = message;
  const field = form.elements[name];
  if (field) field.classList.toggle("invalid", message !== "");
}

function validateField(name) {
  const message = checkField(name);
  showError(name, message);
  return message === "";
}

function validateForm() {
  const names = ["name", "category", "location", "date", "description", "contact"];
  if (form.elements.type.value === "found") names.push("question", "answer");
  let valid = true;
  names.forEach((n) => { if (!validateField(n)) valid = false; });
  return valid;
}

function readForm() {
  const get = (n) => form.elements[n].value.trim();
  const type = form.elements.type.value;
  return {
    type, name: get("name"), category: get("category"), location: get("location"), date: get("date"),
    description: get("description"), contact: get("contact"),
    question: type === "found" ? get("question") : "",
    answer: type === "found" ? get("answer") : ""
  };
}

function handleSubmit(event) {
  event.preventDefault();
  if (!validateForm()) {
    showMessage("Please fix the highlighted fields.", "bad");
    return;
  }
  const data = readForm();
  if (editingId !== null) updateItem(editingId, data);
  else saveItem(data);
  resetForm();
}

function saveItem(data) {
  items.unshift({ id: Date.now(), ...data, status: "open", attempts: 0, createdAt: new Date().toISOString() });
  persist();
  applyFilters();
  showMessage("Report saved: " + data.name + ".", "ok");
}

function resetForm() {
  form.reset();
  editingId = null;
  $("submitBtn").textContent = "Submit report";
  ["name", "category", "location", "date", "description", "contact", "question", "answer"].forEach((n) => showError(n, ""));
  setReportType();
}

/* ---------- FEATURE 4: Edit and delete (Member 1) ---------- */
function loadItemToForm(id) {
  const item = items.find((i) => i.id === id);
  if (!item) return;
  resetForm();
  form.elements.type.value = item.type;
  setReportType();
  ["name", "category", "location", "date", "description", "contact"].forEach((n) => { form.elements[n].value = item[n]; });
  form.elements.question.value = item.question;
  form.elements.answer.value = item.answer;
  editingId = id;
  $("submitBtn").textContent = "Save changes";
  form.scrollIntoView({ behavior: "smooth", block: "start" });
  showMessage("Editing: " + item.name + ". Change the fields, then press Save changes.", "ok");
}

function updateItem(id, data) {
  const index = items.findIndex((i) => i.id === id);
  if (index === -1) return;
  items[index] = { ...items[index], ...data };
  persist();
  applyFilters();
  showMessage("Changes saved.", "ok");
}

function deleteItem(id) {
  const item = items.find((i) => i.id === id);
  if (!item) return;
  if (!confirm('Delete the report "' + item.name + '"? This cannot be undone.')) return;
  items = items.filter((i) => i.id !== id);
  if (editingId === id) resetForm();
  persist();
  applyFilters();
  showMessage("Report deleted.", "ok");
}

/* ---------- FEATURE 2: Item feed (Member 2) ---------- */
function renderFeed(list) {
  const feed = $("feed");
  feed.innerHTML = "";
  if (list.length === 0) {
    const text = items.length === 0
      ? "No reports yet. Use the form to report a lost or found item."
      : "No results found. Try a different keyword or clear the filters.";
    feed.appendChild(el("div", "empty", text));
    return;
  }
  list.forEach((item) => feed.appendChild(buildCard(item)));
}

function buildCard(item) {
  const claimed = item.status === "claimed";
  const card = el("article", "card" + (claimed ? " claimed" : ""));
  const top = el("div", "card-top");
  top.appendChild(el("span", "badge " + (claimed ? "claimed" : item.type), claimed ? "CLAIMED" : item.type.toUpperCase()));
  top.appendChild(el("h3", "", item.name));
  card.appendChild(top);
  card.appendChild(el("div", "meta", item.category + " | " + item.location + " | " + formatDate(item.date)));
  card.appendChild(el("p", "desc", item.description));

  const actions = el("div", "card-actions");
  const edit = el("button", "", "Edit");
  edit.dataset.action = "edit"; edit.dataset.id = item.id;
  const del = el("button", "danger", "Delete");
  del.dataset.action = "delete"; del.dataset.id = item.id;
  actions.append(edit, del);
  if (item.type === "lost" && !claimed) {
    const matches = el("button", "", "Matches");
    matches.dataset.action = "matches"; matches.dataset.id = item.id;
    actions.appendChild(matches);
  }
  if (item.type === "found" && !claimed) {
    if (item.attempts >= MAX_ATTEMPTS) {
      actions.appendChild(el("span", "locked", "Claim locked"));
    } else {
      const claim = el("button", "primary", "Claim");
      claim.dataset.action = "claim"; claim.dataset.id = item.id;
      actions.appendChild(claim);
    }
  }
  card.appendChild(actions);
  return card;
}

/* ---------- FEATURE 3: Search and filter (Member 2) ---------- */
function applyFilters() {
  const q = $("search").value.trim().toLowerCase();
  const type = $("filterType").value;
  const category = $("filterCategory").value;
  const location = $("filterLocation").value;
  const status = $("filterStatus").value;

  const result = items.filter((i) => {
    const text = (i.name + " " + i.description + " " + i.category + " " + i.location).toLowerCase();
    return (q === "" || text.includes(q)) &&
      (type === "" || i.type === type) &&
      (category === "" || i.category === category) &&
      (location === "" || i.location === location) &&
      (status === "" || i.status === status);
  });
  renderFeed(result);
  $("count").textContent = "Showing " + result.length + " of " + items.length + " items";
}

function resetFilters() {
  $("search").value = "";
  ["filterType", "filterCategory", "filterLocation", "filterStatus"].forEach((id) => { $(id).value = ""; });
  applyFilters();
}


/* ---------- FEATURE 5: Claim verification (Member 3) ---------- */
function normalizeAnswer(text) {
  return text.trim().toLowerCase().replace(/\s+/g, " ");
}

function openClaimWindow(id) {
  const item = items.find((i) => i.id === id);
  if (!item || item.status === "claimed" || item.attempts >= MAX_ATTEMPTS) return;
  claimingId = id;
  $("claimItem").textContent = item.name + " (" + item.location + ", " + formatDate(item.date) + ")";
  $("claimQuestion").textContent = item.question;
  $("claimAnswer").value = "";
  $("claimAnswer").disabled = false;
  $("claimSubmit").disabled = false;
  $("claimError").textContent = "";
  $("claimAttempts").textContent = "Attempts left: " + (MAX_ATTEMPTS - item.attempts);
  $("claimModal").showModal();
  $("claimAnswer").focus();
}

function verifyClaim(id, answer) {
  const item = items.find((i) => i.id === id);
  if (!item) return;
  if (answer.trim() === "") {
    $("claimError").textContent = "Type your answer first.";
    return;
  }
  if (normalizeAnswer(answer) === normalizeAnswer(item.answer)) {
    item.status = "claimed";
    item.claimedAt = new Date().toISOString();
    persist();
    closeModal();
    applyFilters();
    showMessage("Verified. " + item.name + " is now marked as claimed.", "ok");
    return;
  }
  item.attempts += 1;
  persist();
  applyFilters();
  const left = MAX_ATTEMPTS - item.attempts;
  if (left <= 0) {
    $("claimError").textContent = "Wrong answer. The claim is now locked. Please see the guard or office.";
    $("claimAnswer").disabled = true;
    $("claimSubmit").disabled = true;
    $("claimAttempts").textContent = "Attempts left: 0";
  } else {
    $("claimError").textContent = "Wrong answer. " + left + (left === 1 ? " attempt" : " attempts") + " left.";
    $("claimAttempts").textContent = "Attempts left: " + left;
    $("claimAnswer").select();
  }
}

function handleClaimKey(event) {
  if (event.key === "Escape") {   // Enter is handled by the form's submit event
    event.preventDefault();
    closeModal();
  }
}

function closeModal() {
  document.querySelectorAll("dialog[open]").forEach((d) => d.close());
  claimingId = null;
}

/* ---------- FEATURE 6: Smart match score (Member 3) ---------- */
const STOP_WORDS = ["the", "and", "with", "for", "from", "near", "was", "are", "has", "have", "left", "found", "lost", "this", "that", "item", "its", "small", "big"];

function keywords(item) {
  const words = (item.name + " " + item.description).toLowerCase().split(/[^a-z0-9]+/);
  return new Set(words.filter((w) => w.length >= 3 && !STOP_WORDS.includes(w)));
}

function computeScore(lost, found) {
  let score = 0;
  if (lost.category === found.category) score += 30;                    // category
  const a = keywords(lost), b = keywords(found);                         // keywords
  if (a.size > 0 && b.size > 0) {
    let shared = 0;
    a.forEach((w) => { if (b.has(w)) shared++; });
    score += (shared / Math.min(a.size, b.size)) * 35;
  }
  if (lost.location === found.location) score += 20;                    // location
  const days = Math.abs(new Date(lost.date) - new Date(found.date)) / 86400000;
  if (days <= 3) score += 15; else if (days <= 7) score += 7.5;         // date
  return Math.round(score);
}

function findMatches(id) {
  const lost = items.find((i) => i.id === id);
  if (!lost) return;
  const results = items
    .filter((i) => i.type === "found" && i.status === "open")
    .map((f) => ({ item: f, score: computeScore(lost, f) }))
    .filter((r) => r.score >= MATCH_MIN)
    .sort((x, y) => y.score - x.score);

  $("matchFor").textContent = "For lost item: " + lost.name + " (" + lost.location + ", " + formatDate(lost.date) + ")";
  const list = $("matchList");
  list.innerHTML = "";
  if (results.length === 0) {
    list.appendChild(el("div", "empty", "No possible matches yet. Check again after more items are reported."));
  }
  results.forEach((r) => {
    const box = el("div", "match");
    const top = el("div", "match-top");
    top.appendChild(el("span", "", r.item.name));
    top.appendChild(el("span", "", r.score + "% match"));
    box.appendChild(top);
    box.appendChild(el("div", "meta", "FOUND | " + r.item.location + " | " + formatDate(r.item.date)));
    const bar = el("div", "bar");
    const fill = el("span", r.score >= 60 ? "" : "mid");
    fill.style.width = r.score + "%";
    bar.appendChild(fill);
    box.appendChild(bar);
    list.appendChild(box);
  });
  $("matchModal").showModal();
}

/* ---------- Start-up and event listeners ---------- */
function initApp() {
  fillSelect(form.elements.category, CATEGORIES, "Select a category");
  fillSelect(form.elements.location, LOCATIONS, "Select a location");
  fillSelect($("filterCategory"), CATEGORIES, "All categories");
  fillSelect($("filterLocation"), LOCATIONS, "All locations");
  form.elements.date.max = todayString();

  loadItems();
  setReportType();
  applyFilters();

  form.addEventListener("submit", handleSubmit);
  form.addEventListener("focusout", (e) => { if (e.target.name && e.target.name !== "type") validateField(e.target.name); });
  form.querySelectorAll('input[name="type"]').forEach((r) => r.addEventListener("change", setReportType));
  $("resetBtn").addEventListener("click", resetForm);

  $("search").addEventListener("input", applyFilters);
  ["filterType", "filterCategory", "filterLocation", "filterStatus"].forEach((id) => $(id).addEventListener("change", applyFilters));
  $("clearFilters").addEventListener("click", resetFilters);

  // one listener on the feed handles every card button (event delegation)
  $("feed").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const id = Number(btn.dataset.id);
    if (btn.dataset.action === "edit") loadItemToForm(id);
    if (btn.dataset.action === "delete") deleteItem(id);
    if (btn.dataset.action === "claim") openClaimWindow(id);
    if (btn.dataset.action === "matches") findMatches(id);
  });

  // claim and match windows
  $("claimForm").addEventListener("submit", (e) => { e.preventDefault(); verifyClaim(claimingId, $("claimAnswer").value); });
  document.querySelectorAll("dialog").forEach((d) => {
    d.addEventListener("keydown", handleClaimKey);
    d.addEventListener("click", (e) => { if (e.target === d) closeModal(); }); // click on the dark backdrop
    d.addEventListener("close", () => { claimingId = null; });
  });
  document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", closeModal));
}

document.addEventListener("DOMContentLoaded", initApp);
