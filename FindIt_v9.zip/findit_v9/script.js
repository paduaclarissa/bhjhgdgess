/* FindIt v7: Student report + Admin dashboard (localStorage only) */
const KEY = "findit_v7_items", SESSION = "findit_v7_admin";
const ADMIN_USER = "admin", ADMIN_PASS = "findit2026";   // demo login (simulation only)
const CATEGORIES = ["Bags", "Electronics", "ID and Cards", "Keys", "Wallet and Money", "Clothing", "Books and Stationery", "Others"];
const LOCATIONS = ["Main Gate", "Library", "Canteen", "Gymnasium", "SITE Building", "Chapel", "Parking Area", "Others"];
const DEPTS = ["SITE", "SBA", "SAS", "SEd", "SON", "SHM", "SCJE", "Others"];
const STOP = ["the", "and", "with", "for", "from", "near", "was", "are", "has", "have", "left", "found", "lost", "this", "that", "item", "its", "small", "big"];
let items = [], tab = "lost", photoData = "", msgTimer = null;
const $ = (id) => document.getElementById(id);
const rf = $("reportForm");

/* ---------- helpers ---------- */
function el(tag, cls, text) { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; }
function fmt(iso, withTime) { const d = new Date(iso); if (isNaN(d)) return iso;
  return d.toLocaleString("en-PH", withTime ? { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" } : { month: "short", day: "numeric", year: "numeric" }); }
function today() { const n = new Date(); n.setMinutes(n.getMinutes() - n.getTimezoneOffset()); return n.toISOString().slice(0, 10); }
function say(text, kind) { const b = $("message"); b.textContent = text; b.className = "message " + (kind || "ok"); b.hidden = false;
  clearTimeout(msgTimer); msgTimer = setTimeout(() => { b.hidden = true; }, 4000); }
function fill(sel, list, first) { sel.innerHTML = ""; const f = el("option", "", first); f.value = ""; sel.appendChild(f);
  list.forEach((o) => { const x = el("option", "", o); x.value = o; sel.appendChild(x); }); }
function isAdmin() { return sessionStorage.getItem(SESSION) === "1"; }

/* ---------- storage ---------- */
function seed() {
  const mk = (id, type, name, cat, loc, date, desc, proof, who, status) => ({ id, ref: "FI-000" + id, type, name, category: cat, location: loc, date,
    description: desc, proof, photo: "", reporter: who, status, note: "", custody: type === "found" ? "SAO Office" : "", messages: [], unread: false,
    history: [{ label: type === "found" ? "Reported found" : "Reported lost", at: date + "T08:00:00.000Z" }] });
  return [
    mk(1, "lost", "Black umbrella", "Others", "Library", "2026-11-03", "Black umbrella with a wooden handle.", "Initials JM carved on the handle",
      { name: "Juan Dela Cruz", sid: "2023-00123", dept: "SITE", block: "BSIT 3-1", contact: "09171234567" }, "Reported"),
    mk(2, "found", "Black folding umbrella", "Others", "Library", "2026-11-04", "Small black folding umbrella found on a chair.", "Handle has carved initials",
      { name: "Maria Santos", sid: "2022-00456", dept: "SBA", block: "BSA 2-2", contact: "maria@example.com" }, "Received at SAO"),
    mk(3, "found", "Student ID card", "ID and Cards", "Main Gate", "2026-11-05", "Student ID near the guard house.", "Name on the card starts with R",
      { name: "Pedro Reyes", sid: "2021-00789", dept: "SITE", block: "BSIT 4-1", contact: "09181234567" }, "Received at SAO")];
}
function load() {
  try { const raw = localStorage.getItem(KEY); if (raw === null) { items = seed(); save(); } else items = JSON.parse(raw);
    if (!Array.isArray(items)) throw 0; } catch (e) { items = []; say("Saved data could not be read.", "bad"); }
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(items)); } catch (e) { say("Could not save. Storage may be full (try a smaller photo).", "bad"); } }
function log(item, label) { item.history.push({ label, at: new Date().toISOString() }); }

/* ---------- views ---------- */
function show(view) {
  if (view === "admin" && !isAdmin()) view = "login";
  document.querySelectorAll('[id^="view-"]').forEach((s) => s.classList.toggle("hidden", s.id !== "view-" + view));
  $("appbar").classList.toggle("hidden", view === "home");
  if (view === "admin") renderAdmin();
  window.scrollTo(0, 0);
}

/* ---------- FEATURE 1: report form (student) ---------- */
function setType() { const f = rf.elements.type.value === "found";
  $("locationLabel").textContent = f ? "Found at" : "Last seen at"; $("dateLabel").textContent = f ? "Date found" : "Date lost"; }
function check(n) {
  const v = rf.elements[n].value.trim();
  const rules = { fullName: [v.length >= 5, "Enter your full name."], studentId: [/^[\w-]{5,}$/.test(v), "Enter a valid Student ID."],
    dept: [v !== "", "Choose your department."], block: [v.length >= 2, "Enter your block."],
    contact: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) || /^09\d{9}$/.test(v), "Enter a valid email or an 11-digit number starting with 09."],
    name: [v.length >= 2, "Enter the item name."], category: [v !== "", "Choose a category."], location: [v !== "", "Choose a location."],
    date: [v !== "" && v <= today(), "Choose a valid date (not in the future)."],
    description: [v.length >= 10, "Describe the item (at least 10 characters)."], proof: [v.length >= 5, "Add proof details for the admin (at least 5 characters)."] };
  return rules[n] && !rules[n][0] ? rules[n][1] : "";
}
function showErr(n, m) { const s = document.querySelector('.error[data-for="' + n + '"]'); if (s) s.textContent = m; rf.elements[n].classList.toggle("invalid", m !== ""); }
function validateForm() { let ok = true;
  ["fullName", "studentId", "dept", "block", "contact", "name", "category", "location", "date", "description", "proof"].forEach((n) => { const m = check(n); showErr(n, m); if (m) ok = false; });
  return ok; }
function nextRef() { const max = items.reduce((m, i) => Math.max(m, parseInt(i.ref.slice(3), 10) || 0), 0); return "FI-" + String(max + 1).padStart(4, "0"); }
function submitReport(e) {
  e.preventDefault();
  if (!validateForm()) { say("Please fix the highlighted fields.", "bad"); return; }
  const g = (n) => rf.elements[n].value.trim(), type = rf.elements.type.value, now = new Date().toISOString();
  const item = { id: Date.now(), ref: nextRef(), type, name: g("name"), category: g("category"), location: g("location"), date: g("date"),
    description: g("description"), proof: g("proof"), photo: photoData,
    reporter: { name: g("fullName"), sid: g("studentId"), dept: g("dept"), block: g("block"), contact: g("contact") },
    status: type === "found" ? "Reported" : "Reported", note: "", custody: "", messages: [], unread: false,
    history: [{ label: type === "found" ? "Reported found" : "Reported lost", at: now }] };
  items.unshift(item); save();
  $("doneRef").textContent = item.ref; rf.reset(); photoData = ""; $("photoPreview").classList.add("hidden"); setType(); show("done");
}
function onPhoto(e) {   // resize to max 480px and store as Base64
  const file = e.target.files[0]; if (!file) return;
  if (!file.type.startsWith("image/")) { say("Please choose an image file.", "bad"); e.target.value = ""; return; }
  const reader = new FileReader();
  reader.onload = () => { const img = new Image(); img.onload = () => {
    const s = Math.min(1, 480 / Math.max(img.width, img.height)), c = document.createElement("canvas");
    c.width = img.width * s; c.height = img.height * s; c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    photoData = c.toDataURL("image/jpeg", 0.7); const p = $("photoPreview"); p.src = photoData; p.classList.remove("hidden"); };
    img.src = reader.result; };
  reader.readAsDataURL(file);
}

/* ---------- student: track a report + messages ---------- */
function thread(item) { const t = el("div", "thread");
  if (!item.messages.length) t.appendChild(el("p", "meta", "No messages yet."));
  item.messages.forEach((m) => { const b = el("div", "msg " + m.from); b.appendChild(el("small", "", (m.from === "admin" ? "Admin" : "Student") + " | " + fmt(m.at, true))); b.appendChild(document.createTextNode(m.text)); t.appendChild(b); });
  return t; }
function renderTrack(item) {
  const box = $("trackResult"); box.innerHTML = ""; box.classList.remove("hidden");
  box.appendChild(el("h3", "", item.name + " (" + item.ref + ")"));
  box.appendChild(el("p", "", "Status: " + item.status));
  if (item.note) box.appendChild(el("p", "question-box", "Note from admin: " + item.note));
  const ul = el("ul"); item.history.forEach((h) => ul.appendChild(el("li", "", h.label + " | " + fmt(h.at, true)))); box.appendChild(ul);
  box.appendChild(el("h3", "", "Messages")); box.appendChild(thread(item));
  const ta = el("textarea"); ta.rows = 2; ta.placeholder = "Ask the admin, for example: has a black wallet been found?"; ta.id = "studentMsg";
  const btn = el("button", "primary", "Send message");
  btn.addEventListener("click", () => { const t = ta.value.trim(); if (!t) return;
    item.messages.push({ from: "student", text: t, at: new Date().toISOString() }); item.unread = true; save(); renderTrack(item); say("Message sent to the admin."); });
  box.append(ta, btn);
}
function track(e) {
  e.preventDefault();
  const ref = $("trackRef").value.trim().toLowerCase(), sid = $("trackSid").value.trim().toLowerCase();
  const item = items.find((i) => i.ref.toLowerCase() === ref && i.reporter.sid.toLowerCase() === sid);
  $("trackError").textContent = item ? "" : "No report found. Check your reference code and Student ID.";
  if (item) renderTrack(item); else $("trackResult").classList.add("hidden");
}

/* ---------- admin: login ---------- */
function login(e) {
  e.preventDefault();
  if ($("loginUser").value.trim() === ADMIN_USER && $("loginPass").value === ADMIN_PASS) {
    sessionStorage.setItem(SESSION, "1"); $("loginError").textContent = ""; $("loginPass").value = ""; show("admin");
  } else $("loginError").textContent = "Wrong username or password.";
}

/* ---------- FEATURES 2 and 3: admin lists, search, tabs ---------- */
function ageDays(i) { return Math.floor((Date.now() - new Date(i.date + "T00:00:00")) / 86400000); }
function renderAdmin() {
  const open = items.filter((i) => i.status !== "Claimed");
  const stats = $("stats"); stats.innerHTML = "";
  [["lost", open.filter((i) => i.type === "lost").length, "Open lost reports"], ["found", open.filter((i) => i.type === "found").length, "Found, waiting for owner"],
    ["claimed", items.length - open.length, "Claimed"], ["old", open.filter((i) => ageDays(i) >= 30).length, "Unclaimed 30+ days"]].forEach(([c, n, l]) => {
    const t = el("div", "tile " + c); t.appendChild(el("strong", "", String(n))); t.appendChild(el("span", "", l)); stats.appendChild(t); });
  const counts = { lost: items.filter((i) => i.type === "lost" && i.status !== "Claimed").length, found: items.filter((i) => i.type === "found" && i.status !== "Claimed").length,
    claimed: items.length - open.length, messages: items.filter((i) => i.messages.length).length };
  document.querySelectorAll("#tabs button").forEach((b) => { b.classList.toggle("active", b.dataset.tab === tab);
    b.textContent = b.dataset.tab[0].toUpperCase() + b.dataset.tab.slice(1) + " (" + counts[b.dataset.tab] + ")"; });
  const q = $("search").value.trim().toLowerCase();
  const list = items.filter((i) => (tab === "messages" ? i.messages.length > 0 : tab === "claimed" ? i.status === "Claimed" : i.type === tab && i.status !== "Claimed") &&
    (q === "" || (i.name + " " + i.ref + " " + i.reporter.name + " " + i.reporter.sid + " " + i.description).toLowerCase().includes(q)) &&
    ($("fCategory").value === "" || i.category === $("fCategory").value) && ($("fLocation").value === "" || i.location === $("fLocation").value));
  const sort = $("sortBy").value;
  list.sort((a, b) => sort === "name" ? a.name.localeCompare(b.name) : sort === "oldest" ? a.id - b.id : b.id - a.id);
  $("count").textContent = "Showing " + list.length + " report" + (list.length === 1 ? "" : "s");
  const feed = $("feed"); feed.innerHTML = "";
  if (!list.length) feed.appendChild(el("div", "empty", "Nothing to show here."));
  list.forEach((i) => feed.appendChild(card(i)));
}
function card(i) {
  const c = el("article", "card" + (i.status === "Claimed" ? " claimed" : ""));
  const top = el("div", "card-top"); top.appendChild(el("span", "badge " + (i.status === "Claimed" ? "claimed" : i.type), i.status === "Claimed" ? "CLAIMED" : i.type.toUpperCase()));
  top.appendChild(el("h3", "", i.name)); if (i.unread) top.appendChild(el("span", "dot")); if (i.status !== "Claimed" && ageDays(i) >= 30) top.appendChild(el("span", "badge stale", "30+ DAYS"));
  c.appendChild(top);
  if (i.photo) { const im = el("img", "thumb"); im.src = i.photo; im.alt = ""; c.appendChild(im); }
  c.appendChild(el("div", "meta", i.ref + " | " + i.category + " | " + i.location + " | " + fmt(i.date)));
  c.appendChild(el("div", "meta", "Reporter: " + i.reporter.name + " (" + i.reporter.sid + ", " + i.reporter.dept + " " + i.reporter.block + ")"));
  c.appendChild(el("div", "custody", "Status: " + i.status + (i.custody ? " | Held at " + i.custody : "")));
  const a = el("div", "card-actions"), v = el("button", "primary", "View"); v.dataset.view = i.id; a.appendChild(v); c.appendChild(a);
  return c;
}

/* ---------- FEATURE 6: match score (admin) ---------- */
function keywords(i) { return new Set((i.name + " " + i.description).toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length >= 3 && !STOP.includes(w))); }
function computeScore(lost, found) {
  let s = 0; if (lost.category === found.category) s += 30;
  const a = keywords(lost), b = keywords(found);
  if (a.size && b.size) { let n = 0; a.forEach((w) => { if (b.has(w)) n++; }); s += (n / Math.min(a.size, b.size)) * 35; }
  if (lost.location === found.location) s += 20;
  const d = Math.abs(new Date(lost.date) - new Date(found.date)) / 86400000; s += d <= 3 ? 15 : d <= 7 ? 7.5 : 0;
  return Math.round(s);
}
function matchesFor(i) {
  const other = i.type === "lost" ? "found" : "lost";
  return items.filter((x) => x.type === other && x.status !== "Claimed")
    .map((x) => ({ item: x, score: i.type === "lost" ? computeScore(i, x) : computeScore(x, i) })).filter((r) => r.score >= 40).sort((p, q) => q.score - p.score);
}

/* ---------- FEATURE 4: View details (admin) ---------- */
function kv(parent, pairs) { const dl = el("dl", "kv"); pairs.forEach(([k, v]) => { dl.appendChild(el("dt", "", k)); dl.appendChild(el("dd", "", v)); }); parent.appendChild(dl); }
function openDetail(id) {
  const i = items.find((x) => x.id === id); if (!i) return;
  i.unread = false; save();
  const d = $("detail"); d.innerHTML = "";
  d.appendChild(el("h2", "", i.name + " (" + i.ref + ")"));
  if (i.photo) { const p = el("img", "photo-preview"); p.src = i.photo; p.alt = "Photo of " + i.name; d.appendChild(p); }
  kv(d, [["Type", i.type.toUpperCase()], ["Status", i.status], ["Category", i.category], ["Location", i.location], ["Date", fmt(i.date)],
    ["Description", i.description], ["Proof details", i.proof], ["Held at", i.custody || "Not yet received"],
    ["Reporter", i.reporter.name + " | " + i.reporter.sid + " | " + i.reporter.dept + " " + i.reporter.block]]);
  const msg = encodeURIComponent("Hello " + i.reporter.name + ", regarding your report " + i.ref + " (" + i.name + "). " + (i.note || "Please visit the SAO office with your school ID."));
  const row = el("div", "actions"), c = i.reporter.contact;
  const link = el("a", "", c.includes("@") ? "Email reporter" : "Text reporter"); link.className = "btn-link";
  link.href = c.includes("@") ? "mailto:" + c + "?subject=" + encodeURIComponent("FindIt " + i.ref) + "&body=" + msg : "sms:" + c + "?&body=" + msg;
  row.appendChild(link); d.appendChild(row);

  d.appendChild(el("h3", "", "Note for the student (shown in Track a Report)"));
  const note = el("textarea"); note.rows = 2; note.value = i.note; d.appendChild(note);
  const sv = el("button", "", "Save note"); sv.addEventListener("click", () => { i.note = note.value.trim(); log(i, "Note updated"); save(); say("Note saved."); openDetail(id); }); d.appendChild(sv);

  const ms = matchesFor(i); d.appendChild(el("h3", "", "Possible matches (40% and above)"));
  if (!ms.length) d.appendChild(el("p", "meta", "No possible matches yet."));
  ms.forEach((r) => { const b = el("div", "match"), t = el("div", "match-top");
    t.appendChild(el("span", "", r.item.name + " (" + r.item.ref + ")")); t.appendChild(el("span", "", r.score + "% match")); b.appendChild(t);
    b.appendChild(el("div", "meta", r.item.type.toUpperCase() + " | " + r.item.location + " | " + fmt(r.item.date) + " | " + r.item.reporter.name));
    const bar = el("div", "bar"), f = el("span", r.score >= 60 ? "" : "mid"); f.style.width = r.score + "%"; bar.appendChild(f); b.appendChild(bar);
    const lost = i.type === "lost" ? i : r.item, nb = el("button", "", "Notify owner of the lost report");
    nb.addEventListener("click", () => { lost.status = "Possible match found"; lost.note = "A possible match was found. Please visit the SAO office with your school ID.";
      log(lost, "Possible match found (" + r.score + "%)"); save(); say("Status updated. Use Email or Text to notify " + lost.reporter.name + "."); openDetail(lost.id); });
    b.appendChild(nb); d.appendChild(b); });

  if (i.type === "found" && !i.custody) { const rb = el("button", "primary", "Mark as received at SAO");
    rb.addEventListener("click", () => { i.custody = "SAO Office"; i.status = "Received at SAO"; log(i, "Received at SAO"); save(); renderAdmin(); openDetail(id); }); d.appendChild(rb); }

  if (i.status !== "Claimed") {   // FEATURE 5: admin-only claim with checklist
    d.appendChild(el("h3", "", "Release to owner (claim)"));
    const nm = el("input"); nm.placeholder = "Claimant full name"; const sd = el("input"); sd.placeholder = "Claimant Student ID";
    const ck = el("div", "checks"), boxes = ["Name and Student ID match the report", "Proof details match the item", "School ID was checked"].map((t) => {
      const l = el("label"), c2 = el("input"); c2.type = "checkbox"; l.append(c2, document.createTextNode(t)); ck.appendChild(l); return c2; });
    const cb = el("button", "primary", "Mark as claimed");
    cb.addEventListener("click", () => {
      if (nm.value.trim().length < 3 || sd.value.trim().length < 5) { say("Enter the claimant's name and Student ID.", "bad"); return; }
      if (!boxes.every((b) => b.checked)) { say("Complete the verification checklist first.", "bad"); return; }
      i.status = "Claimed"; i.claimedBy = nm.value.trim() + " (" + sd.value.trim() + ")"; i.claimedAt = new Date().toISOString();
      log(i, "Claimed by " + i.claimedBy); save(); say(i.name + " marked as claimed."); d.close(); renderAdmin(); });
    d.append(nm, sd, ck, cb);
  } else d.appendChild(el("p", "meta", "Claimed by " + (i.claimedBy || "n/a") + " on " + fmt(i.claimedAt || i.date, true)));

  d.appendChild(el("h3", "", "Messages")); d.appendChild(thread(i));
  const rt = el("textarea"); rt.rows = 2; rt.placeholder = "Reply to the student"; const rb2 = el("button", "", "Send reply");
  rb2.addEventListener("click", () => { const t = rt.value.trim(); if (!t) return; i.messages.push({ from: "admin", text: t, at: new Date().toISOString() }); save(); openDetail(id); });
  d.append(rt, rb2);
  d.appendChild(el("h3", "", "Timeline")); const ul = el("ul"); i.history.forEach((h) => ul.appendChild(el("li", "", h.label + " | " + fmt(h.at, true)))); d.appendChild(ul);
  const foot = el("div", "actions"), del = el("button", "danger", "Delete report"), cl = el("button", "", "Close");
  del.addEventListener("click", () => { if (confirm("Delete " + i.ref + "? This cannot be undone.")) { items = items.filter((x) => x.id !== id); save(); d.close(); renderAdmin(); say("Report deleted."); } });
  cl.addEventListener("click", () => { d.close(); renderAdmin(); }); foot.append(del, cl); d.appendChild(foot);
  if (!d.open) d.showModal();
}

/* ---------- start-up ---------- */
function init() {
  fill(rf.elements.category, CATEGORIES, "Select a category"); fill(rf.elements.location, LOCATIONS, "Select a location"); fill(rf.elements.dept, DEPTS, "Select department");
  fill($("fCategory"), CATEGORIES, "All categories"); fill($("fLocation"), LOCATIONS, "All locations");
  rf.elements.date.max = today(); load(); setType(); show("home");
  document.addEventListener("click", (e) => {
    const go = e.target.closest("[data-go]"); if (go) show(go.dataset.go);
    const tb = e.target.closest("[data-tab]"); if (tb) { tab = tb.dataset.tab; renderAdmin(); }
    const vb = e.target.closest("[data-view]"); if (vb) openDetail(Number(vb.dataset.view));
  });
  rf.addEventListener("submit", submitReport);
  rf.addEventListener("focusout", (e) => { const n = e.target.name; if (n && n !== "type" && rf.elements[n]) showErr(n, check(n)); });
  rf.querySelectorAll('input[name="type"]').forEach((r) => r.addEventListener("change", setType));
  $("photo").addEventListener("change", onPhoto);
  $("trackForm").addEventListener("submit", track);
  $("loginForm").addEventListener("submit", login);
  $("logoutBtn").addEventListener("click", () => { sessionStorage.removeItem(SESSION); show("home"); });
  $("search").addEventListener("input", renderAdmin);
  ["fCategory", "fLocation", "sortBy"].forEach((id) => $(id).addEventListener("change", renderAdmin));
  $("clearFilters").addEventListener("click", () => { $("search").value = ""; $("fCategory").value = ""; $("fLocation").value = ""; $("sortBy").value = "newest"; renderAdmin(); });
  $("detail").addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); $("detail").close(); renderAdmin(); } });
}
document.addEventListener("DOMContentLoaded", init);
